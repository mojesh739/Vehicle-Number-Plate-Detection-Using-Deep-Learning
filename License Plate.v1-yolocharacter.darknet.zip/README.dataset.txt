# License Plate > yoloCharacter
https://universe.roboflow.com/antony-samuel/license-plate-odlmn

Provided by a Roboflow user
License: CC BY 4.0

